﻿' Макрос SolidWorks: модель с деревом построения (FrogFlow Studio, CAD Intelligence)
' Источник: model.py. Единицы: мм. Ось Y SolidWorks = ось Z модели.
' Модель сдвинута на (-0.797; 0.026) мм по X и Z, чтобы ось вращения прошла через начало координат.
' Запуск: Инструменты → Макрос → Создать, вставить этот текст в модуль, запустить main.
' ВНИМАНИЕ: сгенерировано автоматически, перед показом проверить в SolidWorks.
Option Explicit
Dim swApp As Object, Part As Object, SM As Object, FM As Object

Function BasePlane(idx As Integer) As Object
    ' 1 = Спереди, 2 = Сверху, 3 = Справа: по порядку в дереве, имена зависят от языка
    Dim f As Object, n As Integer
    Set f = Part.FirstFeature
    Do While Not f Is Nothing
        If f.GetTypeName2 = "RefPlane" Then
            n = n + 1
            If n = idx Then Set BasePlane = f: Exit Function
        End If
        Set f = f.GetNextFeature
    Loop
End Function

Function TopAt(z As Double) As Object
    ' плоскость, параллельная «Сверху», на высоте z (м); на нуле — сама «Сверху»
    Part.ClearSelection2 True
    BasePlane(2).Select2 False, 0
    If Abs(z) < 0.0000001 Then
        Set TopAt = BasePlane(2)
    ElseIf z > 0 Then
        Set TopAt = FM.InsertRefPlane(8, z, 0, 0, 0, 0)
    Else
        Set TopAt = FM.InsertRefPlane(8 + 256, -z, 0, 0, 0, 0)
    End If
End Function

Function OpenSketch(pl As Object) As Object
    Part.ClearSelection2 True
    pl.Select2 False, 0
    SM.InsertSketch True
    Set OpenSketch = SM.ActiveSketch
End Function

Function CloseSketch(sk As Object) As Object
    Dim f As Object
    SM.InsertSketch True
    Part.ClearSelection2 True
    Set f = Part.FeatureByPositionReverse(0)  ' только что закрытый эскиз
    f.Select2 False, 0
    Set CloseSketch = f
End Function

Sub Boss(h As Double)
    ' на середину: направление вытягивания не важно, слой стоит на высоте z..z+h
    FM.FeatureExtrusion2 True, False, False, 6, 0, h, 0, False, False, False, False, 0, 0, _
        False, False, False, False, True, True, True, 0, 0, False
End Sub

Sub Cut(h As Double)
    FM.FeatureCut4 True, False, False, 6, 0, h, 0, False, False, False, False, 0, 0, _
        False, False, False, False, False, True, True, True, True, False, 0, 0, False, False
End Sub

Sub main()
    Set swApp = Application.SldWorks
    Set Part = swApp.NewDocument(swApp.GetUserPreferenceStringValue(8), 0, 0, 0)
    Set SM = Part.SketchManager
    Set FM = Part.FeatureManager
    SM.AddToDB = True
    SM.DisplayWhenAdded = False
    Dim sk As Object
    ' Тело вращения 1: профиль радиус/высота, ось — вертикаль через начало
    Set sk = OpenSketch(BasePlane(1))
    SM.CreateLine 0.0000000, 0.0000000, 0, 0.0449950, 0.0000000, 0
    SM.CreateLine 0.0449950, 0.0000000, 0, 0.0449950, 0.0100000, 0
    SM.CreateLine 0.0449950, 0.0100000, 0, 0.0220080, 0.0100000, 0
    SM.CreateLine 0.0220080, 0.0100000, 0, 0.0220080, 0.0250000, 0
    SM.CreateLine 0.0220080, 0.0250000, 0, 0.0000000, 0.0250000, 0
    SM.CreateLine 0.0000000, 0.0250000, 0, 0.0000000, 0.0000000, 0
    SM.CreateCenterLine 0, -0.0010000, 0, 0, 0.0260000, 0
    CloseSketch sk
    FM.FeatureRevolve2 True, True, False, False, False, False, 0, 0, 6.283185307, 0, _
        False, False, 0.01, 0.01, 0, 0, 0, True, True, True
    ' Отверстие 1: Ø8.008 мм, высота -0.050…10.050 мм
    Set sk = OpenSketch(TopAt(0.0050000))
    SM.CreateCircleByRadius 0.0218130, -0.0260710, 0, 0.0040040
    CloseSketch sk
    Cut 0.0101000
    ' Отверстие 2: Ø8.000 мм, высота -0.050…10.050 мм
    Set sk = OpenSketch(TopAt(0.0050000))
    SM.CreateCircleByRadius 0.0116740, 0.0319330, 0, 0.0040000
    CloseSketch sk
    Cut 0.0101000
    ' Отверстие 3: Ø24.998 мм, высота -0.050…25.050 мм
    Set sk = OpenSketch(TopAt(0.0125000))
    SM.CreateCircleByRadius -0.0000030, 0.0000010, 0, 0.0124990
    CloseSketch sk
    Cut 0.0251000
    ' Отверстие 4: Ø7.998 мм, высота -0.050…10.050 мм
    Set sk = OpenSketch(TopAt(0.0050000))
    SM.CreateCircleByRadius -0.0116810, -0.0319310, 0, 0.0039990
    CloseSketch sk
    Cut 0.0101000
    ' Отверстие 5: Ø8.004 мм, высота -0.050…10.050 мм
    Set sk = OpenSketch(TopAt(0.0050000))
    SM.CreateCircleByRadius -0.0218200, 0.0260760, 0, 0.0040020
    CloseSketch sk
    Cut 0.0101000
    ' Отверстие 6: Ø8.004 мм, высота -0.050…10.050 мм
    Set sk = OpenSketch(TopAt(0.0050000))
    SM.CreateCircleByRadius -0.0334920, -0.0058540, 0, 0.0040020
    CloseSketch sk
    Cut 0.0101000
    ' Отверстие 7: Ø8.004 мм, высота -0.050…10.050 мм
    Set sk = OpenSketch(TopAt(0.0050000))
    SM.CreateCircleByRadius 0.0334930, 0.0058560, 0, 0.0040020
    CloseSketch sk
    Cut 0.0101000
    SM.AddToDB = False
    SM.DisplayWhenAdded = True
    Part.ViewZoomtofit2
    MsgBox "Построено: слоёв 0, тел вращения 1, вырезов 0, отверстий 7"
End Sub
